package twitter4j;

/* This class is a stub to trick Processing into importing the twitter4j package automatically. */
public class ImportHelper {

}
